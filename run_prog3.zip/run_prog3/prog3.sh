#!/bin/bash
gcc -o theLA.out theLA.c;
./theLA.out;
gcc -o myGen.out myGen.c;
./myGen.out;
gcc -o P-Machine.out P-Machine.c;
./P-Machine.out
