Daniel Moore
Tabitha Cliver
HW 3 - 3/31/2013
for COP3402
README File

Included Files:

myGen.c - Code generator
P-Machine.c - Virtual Machine
theLA.c - Lexical Analyzer
test.in - Copy code written in PL/0 to run
prog3.sh - Bash script that runs compiler

To Run Compiler:

Copy desired code into file "test.in"

From Command line type:
chmod +x ./prog.sh [enter]
./prog.sh [enter]

The terminal will output debug statements and any errors that may stop the compilation process.

The final terminal output will be the Virtual Machine fetch and execution process.

The file "output.txt" is created and tracks the appropriate tokens as the Lexical Analyzer runs.

This compiler should be able to handle procedure calls up to the three level limit.




